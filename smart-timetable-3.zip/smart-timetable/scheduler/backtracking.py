"""
backtracking.py
-----------------
The heart of the project: a recursive Backtracking search that solves
the timetable Constraint Satisfaction Problem (CSP).

High-level pseudocode (matches the brief exactly):

    function schedule(index):
        if index == len(sessions):
            return success                      # base case: everything placed

        session = sessions[index]                # greedy-ordered: hardest first
        for candidate (day, room, periods) of session, best-first:
            if constraints_satisfied(candidate):
                assign(candidate)                # make a choice
                if schedule(index + 1):          # recurse (try to complete the rest)
                    return success
                undo(candidate)                  # BACKTRACK: undo the choice
        return failure                            # no candidate worked -> dead end

Because sessions are ordered by the Greedy heuristic (greedy.py) and
candidates are ordered by a soft-constraint score before being tried,
this is a "Greedy + Backtracking" hybrid: greedy narrows the search,
backtracking guarantees correctness (it will only report success if
every hard constraint really is satisfied).
"""

from .constraints import ScheduleState, faculty_marked_available, find_consecutive_windows
from .greedy import order_subjects, expand_into_sessions

# Safety valve so a pathological/over-constrained input can't hang the
# Flask request forever. In a real product this would be a proper
# timeout; for a student project a step counter is simple & explainable.
MAX_BACKTRACK_STEPS = 300_000


class _Aborted(Exception):
    pass


def _candidate_windows_for_day(day, session, teaching_periods, faculty_availability_map):
    """All (period-window) options for this session on this day where
    the faculty is at least *marked available* (a hard constraint we
    can check before touching class/room state)."""
    windows = find_consecutive_windows(teaching_periods, session["size"])
    valid = []
    for window in windows:
        if all(faculty_marked_available(faculty_availability_map, session["faculty_id"], day, p)
               for p in window):
            valid.append(window)
    return valid


def _rooms_for_session(session, rooms):
    wanted_type = "Lab" if session["subject_type"] == "Lab" else "Classroom"
    return [r for r in rooms if r["room_type"] == wanted_type]


def _soft_score(state, session, day, window):
    """
    Lower score = tried first. Encodes the SOFT constraints:
      - prefer days this subject hasn't already used (spread across week)
      - prefer days the faculty isn't already heavily loaded
      - mild penalty for being placed immediately after the same
        subject already taught to this class (avoid monotony)
    """
    subj_day_key = (session["class_id"], session["subject_id"], day)
    subject_spread_penalty = state.subject_day_count.get(subj_day_key, 0) * 10

    fac_load_key = (session["faculty_id"], day)
    faculty_load_penalty = state.faculty_day_load.get(fac_load_key, 0)

    back_to_back_penalty = 0
    prev_period = window[0] - 1
    if state.last_subject_in_slot.get((session["class_id"], day, prev_period)) == session["subject_id"]:
        back_to_back_penalty = 5

    return subject_spread_penalty + faculty_load_penalty + back_to_back_penalty


def _build_candidates(state, session, rooms, working_days, teaching_periods, faculty_availability_map):
    candidates = []
    rooms_of_type = _rooms_for_session(session, rooms)
    for day in working_days:
        windows = _candidate_windows_for_day(day, session, teaching_periods, faculty_availability_map)
        for window in windows:
            for room in rooms_of_type:
                candidates.append((day, window, room))
    # Best-first ordering (soft constraints) -- pure heuristic, does not
    # affect correctness, only search speed and timetable "niceness".
    candidates.sort(key=lambda c: _soft_score(state, session, c[0], c[1]))
    return candidates


def _backtrack(state, sessions, index, rooms, working_days, teaching_periods,
                faculty_availability_map, step_counter, unscheduled_reasons):
    """Recursive CSP search. Returns True if sessions[index:] were all placed."""
    if index == len(sessions):
        return True  # base case: every session successfully scheduled

    step_counter[0] += 1
    if step_counter[0] > MAX_BACKTRACK_STEPS:
        raise _Aborted()

    session = sessions[index]
    candidates = _build_candidates(state, session, rooms, working_days,
                                    teaching_periods, faculty_availability_map)

    if not candidates:
        unscheduled_reasons.setdefault(session["subject_id"], {
            "subject_name": session["subject_name"], "missed_sessions": 0
        })

    for day, window, room in candidates:
        if not state.block_is_free(session["faculty_id"], session["class_id"], room["id"], day, window):
            continue  # hard constraint failed (HARD CONSTRAINTS 1,2,3,5,6,7,8)

        # ---- ASSIGN ----
        record = state.assign(session["class_id"], session["subject_id"],
                               session["faculty_id"], room["id"], day, window)
        for p in window:
            state.last_subject_in_slot[(session["class_id"], day, p)] = session["subject_id"]

        if _backtrack(state, sessions, index + 1, rooms, working_days, teaching_periods,
                      faculty_availability_map, step_counter, unscheduled_reasons):
            return True

        # ---- BACKTRACK: undo and try the next candidate ----
        state.undo(record)

    # every candidate failed for this session -> record why, for the Conflict Report
    entry = unscheduled_reasons.setdefault(session["subject_id"], {
        "subject_name": session["subject_name"], "missed_sessions": 0
    })
    entry["missed_sessions"] += 1
    return False


def generate_timetable(subjects, rooms, faculty_availability_map, working_days, time_slots):
    """
    Public entry point used by app.py.

    subjects: list[dict] with keys id, subject_name, faculty_id, class_id,
              lectures_per_week, subject_type, requires_consecutive_periods, block_size
    rooms: list[dict] with keys id, room_name, room_type, capacity
    faculty_availability_map: dict[(faculty_id, day, period)] -> bool
    working_days: list[str]
    time_slots: list[dict] with keys period_index, start_time, end_time, is_break

    Returns a dict:
        success, assignments, conflicts (list[str]), steps, sessions_total, sessions_scheduled
    """
    teaching_periods = sorted(t["period_index"] for t in time_slots if not t["is_break"])
    break_periods = [t["period_index"] for t in time_slots if t["is_break"]]

    state = ScheduleState(working_days, teaching_periods, break_periods)

    ordered_subjects = order_subjects(subjects, faculty_availability_map, working_days, teaching_periods)
    sessions = expand_into_sessions(ordered_subjects)

    conflicts = []

    # ---- Pre-flight validation (fail fast with a clear message rather
    # than silently producing a broken timetable) ----
    if not subjects:
        conflicts.append("No subjects have been defined yet. Add subjects before generating a timetable.")
    if not rooms:
        conflicts.append("No rooms/labs have been defined yet. Add at least one classroom and one lab.")
    total_capacity = len(working_days) * len(teaching_periods)
    for subj in subjects:
        if subj["lectures_per_week"] > total_capacity:
            conflicts.append(
                f"'{subj['subject_name']}' requires {subj['lectures_per_week']} lectures/week "
                f"but only {total_capacity} teaching periods exist per week."
            )
    if not _rooms_for_session({"subject_type": "Lab"}, rooms) and any(s["subject_type"] == "Lab" for s in subjects):
        conflicts.append("A Lab subject exists but no room with type 'Lab' has been added.")
    if not _rooms_for_session({"subject_type": "Theory"}, rooms) and any(s["subject_type"] != "Lab" for s in subjects):
        conflicts.append("A Theory subject exists but no room with type 'Classroom' has been added.")

    if conflicts:
        return {
            "success": False,
            "assignments": [],
            "conflicts": conflicts,
            "steps": 0,
            "sessions_total": len(sessions),
            "sessions_scheduled": 0,
        }

    step_counter = [0]
    unscheduled_reasons = {}
    aborted = False
    try:
        success = _backtrack(state, sessions, 0, rooms, working_days, teaching_periods,
                              faculty_availability_map, step_counter, unscheduled_reasons)
    except _Aborted:
        success = False
        aborted = True

    if not success:
        if aborted:
            conflicts.append(
                f"Search exceeded {MAX_BACKTRACK_STEPS:,} backtracking steps without finding a full "
                "solution. The constraints are likely too tight -- try adding more rooms, more "
                "faculty availability, or reducing lecture load."
            )
        for subject_id, info in unscheduled_reasons.items():
            conflicts.append(
                f"Could not place {info['missed_sessions']} session(s) of "
                f"'{info['subject_name']}' -- faculty availability, room availability or "
                "consecutive-period requirements could not all be satisfied simultaneously."
            )
        if not conflicts:
            conflicts.append("The scheduler could not find a valid timetable with the current data.")

    return {
        "success": success,
        "assignments": state.assignments,
        "conflicts": conflicts,
        "steps": step_counter[0],
        "sessions_total": len(sessions),
        "sessions_scheduled": len(state.assignments) if not success else len(sessions),
        "state": state,
    }
