"""
optimizer.py
-------------
Computes a 0-100 "Scheduling Score" for a completed timetable by
measuring how well the SOFT constraints were satisfied (hard
constraints are guaranteed by the backtracking search itself, so this
score only judges *quality*, not correctness).

Weighted components:
    40 pts - constraint satisfaction (sessions actually scheduled)
    20 pts - subject distribution across different days
    20 pts - faculty workload balance across the week
    20 pts - consecutive-lecture reduction (fewer repeats back-to-back)
"""

from statistics import pstdev


def _distribution_score(assignments):
    """Reward subjects that appear on MORE distinct days (spread out)
    rather than being crammed onto one or two days."""
    per_subject_days = {}
    per_subject_sessions = {}
    for a in assignments:
        key = (a["class_id"], a["subject_id"])
        per_subject_days.setdefault(key, set()).add(a["day"])
        per_subject_sessions[key] = per_subject_sessions.get(key, 0) + 1

    if not per_subject_days:
        return 20.0

    ratios = []
    for key, days in per_subject_days.items():
        sessions = per_subject_sessions[key]
        # best possible = 1 session per distinct day
        ratios.append(len(days) / sessions)
    return 20.0 * (sum(ratios) / len(ratios))


def _workload_balance_score(assignments):
    """Reward faculty whose daily teaching load is roughly even across
    the working days they teach (low standard deviation = balanced)."""
    faculty_day_counts = {}
    for a in assignments:
        key = a["faculty_id"]
        faculty_day_counts.setdefault(key, {})
        day = a["day"]
        faculty_day_counts[key][day] = faculty_day_counts[key].get(day, 0) + len(a["periods"])

    if not faculty_day_counts:
        return 20.0

    normalized = []
    for fac, day_counts in faculty_day_counts.items():
        counts = list(day_counts.values())
        if len(counts) <= 1:
            normalized.append(1.0)
            continue
        spread = pstdev(counts)
        avg = sum(counts) / len(counts)
        # spread of 0 -> perfectly balanced -> score 1.0
        normalized.append(max(0.0, 1.0 - (spread / (avg + 1e-6))))
    return 20.0 * (sum(normalized) / len(normalized))


def _consecutive_penalty_score(assignments):
    """Penalize the same subject appearing in back-to-back periods on
    the same day for the same class more than necessary (labs are
    exempt since consecutive periods are a hard requirement there)."""
    by_class_day = {}
    for a in assignments:
        key = (a["class_id"], a["day"])
        by_class_day.setdefault(key, []).extend(
            (p, a["subject_id"], a.get("is_lab", False)) for p in a["periods"]
        )

    total_pairs = 0
    bad_pairs = 0
    for key, entries in by_class_day.items():
        entries.sort()
        for i in range(len(entries) - 1):
            p1, subj1, lab1 = entries[i]
            p2, subj2, lab2 = entries[i + 1]
            if p2 - p1 == 1:
                total_pairs += 1
                if subj1 == subj2 and not lab1:
                    bad_pairs += 1

    if total_pairs == 0:
        return 20.0
    return 20.0 * (1 - (bad_pairs / total_pairs))


def calculate_score(result):
    """
    result: the dict returned by backtracking.generate_timetable()
    Returns (score:int, breakdown:dict)
    """
    assignments = result["assignments"]
    sessions_total = max(1, result["sessions_total"])
    sessions_scheduled = result["sessions_scheduled"]

    satisfaction = 40.0 * (sessions_scheduled / sessions_total)
    distribution = _distribution_score(assignments)
    balance = _workload_balance_score(assignments)
    consecutive = _consecutive_penalty_score(assignments)

    total = round(satisfaction + distribution + balance + consecutive)
    total = max(0, min(100, total))

    breakdown = {
        "constraint_satisfaction": round(satisfaction, 1),
        "subject_distribution": round(distribution, 1),
        "faculty_balance": round(balance, 1),
        "consecutive_reduction": round(consecutive, 1),
    }
    return total, breakdown
