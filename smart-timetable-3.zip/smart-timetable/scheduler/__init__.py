# scheduler package
# Contains the DSA logic for the Smart Time Table Scheduling System:
#   greedy.py        - priority ordering of subjects (Greedy strategy)
#   constraints.py    - hard-constraint checking functions (CSP rules)
#   backtracking.py   - recursive backtracking search (CSP solver)
#   optimizer.py      - soft-constraint scoring of a finished timetable
from .optimizer import calculate_score  # noqa: F401
from .backtracking import generate_timetable  # noqa: F401
