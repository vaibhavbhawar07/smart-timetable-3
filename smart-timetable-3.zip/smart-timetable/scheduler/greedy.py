"""
greedy.py
----------
Greedy prioritization ("schedule the hardest thing first").

Pure backtracking eventually finds a valid timetable regardless of the
order subjects are tried in, but a bad order causes far more
dead-ends and re-tries. This module implements the classic CSP
heuristic "Most Constrained Variable First": subjects that are
hardest to place (fewest legal options) are scheduled first, while
they still have the most free slots to choose from.

Priority order requested by the project brief:
    1. Laboratory sessions
    2. Subjects/faculty with limited availability
    3. Subjects requiring consecutive periods
    4. Subjects with high weekly lecture requirements
    5. Normal theory subjects
"""


def _availability_count(subject, faculty_availability_map, working_days, teaching_periods):
    """How many (day, period) combinations this subject's faculty is
    actually free for. Smaller = more constrained = scheduled first."""
    count = 0
    for day in working_days:
        for period in teaching_periods:
            if faculty_availability_map.get((subject["faculty_id"], day, period), True):
                count += 1
    return count


def priority_key(subject, faculty_availability_map, working_days, teaching_periods):
    """
    Build a sortable tuple. Python sorts tuples lexicographically,
    so putting the "most important, smallest = first" signal in
    position 0 gives us exactly the priority order from the brief.
    """
    is_lab = 0 if subject["subject_type"] == "Lab" else 1                 # labs (0) before theory (1)
    availability = _availability_count(subject, faculty_availability_map,
                                        working_days, teaching_periods)     # fewer free slots -> first
    needs_consecutive = 0 if subject["requires_consecutive_periods"] else 1
    lectures_desc = -subject["lectures_per_week"]                          # more lectures -> first (negated for ascending sort)

    return (is_lab, availability, needs_consecutive, lectures_desc, subject["subject_name"])


def order_subjects(subjects, faculty_availability_map, working_days, teaching_periods):
    """Return subjects sorted from hardest-to-place to easiest."""
    return sorted(
        subjects,
        key=lambda s: priority_key(s, faculty_availability_map, working_days, teaching_periods)
    )


def expand_into_sessions(subjects_ordered):
    """
    Turn each subject into one or more concrete 'session' tasks the
    backtracking algorithm will place one at a time.

    - Theory subject with lectures_per_week=4  -> 4 sessions of size 1
    - Lab subject with lectures_per_week=4, block_size=2 -> 2 sessions of size 2

    Order is preserved (labs/hard subjects' sessions come first
    because `subjects_ordered` is already priority-sorted).
    """
    sessions = []
    for subject in subjects_ordered:
        block = subject["block_size"] if subject["requires_consecutive_periods"] else 1
        block = max(1, block)
        total = subject["lectures_per_week"]

        remaining = total
        while remaining > 0:
            size = block if remaining >= block else remaining
            sessions.append({
                "subject_id": subject["id"],
                "subject_name": subject["subject_name"],
                "faculty_id": subject["faculty_id"],
                "class_id": subject["class_id"],
                "subject_type": subject["subject_type"],
                "size": size,
            })
            remaining -= size
    return sessions
