"""
constraints.py
---------------
Hard-constraint checking for the timetable Constraint Satisfaction
Problem (CSP).

A timetable is a CSP where:
    Variables    = every lecture session that must be scheduled
    Domain       = every (day, starting_period, room) triple
    Constraints  = the hard rules below

Every function here answers a single yes/no question about whether
placing a session at a particular (day, period) would break a rule.
Keeping each rule as its own small function is what lets the
backtracking search "check constraints before assigning" cheaply,
and it is also what we point to in the viva when asked
"how did you detect faculty / room / class conflicts?".
"""


class ScheduleState:
    """
    Mutable state carried through the backtracking recursion.

    Internally this is just three hash sets (Python `set`) used as
    O(1) lookup tables -- this is the "Hash Map / Set" data
    structure referenced in the README's DSA section.
    """

    def __init__(self, working_days, teaching_periods, break_periods):
        self.working_days = working_days              # list[str]
        self.teaching_periods = teaching_periods       # list[int] (non-break period indices, in order)
        self.break_periods = set(break_periods)        # set[int]

        # busy[(entity_id, day, period)] = True  -> O(1) conflict lookup
        self.faculty_busy = set()
        self.class_busy = set()
        self.room_busy = set()

        # Bookkeeping used by soft-constraint scoring / distribution heuristics
        self.faculty_day_load = {}          # (faculty_id, day) -> count
        self.subject_day_count = {}         # (class_id, subject_id, day) -> count
        self.last_subject_in_slot = {}      # (class_id, day, period-1) -> subject_id, for "avoid back-to-back same subject"

        self.assignments = []               # list of dicts, the final/partial timetable

    # ---- basic hard-constraint checks -------------------------------

    def is_break(self, period):
        return period in self.break_periods

    def is_faculty_free(self, faculty_id, day, period):
        return (faculty_id, day, period) not in self.faculty_busy

    def is_class_free(self, class_id, day, period):
        return (class_id, day, period) not in self.class_busy

    def is_room_free(self, room_id, day, period):
        return (room_id, day, period) not in self.room_busy

    def block_is_free(self, faculty_id, class_id, room_id, day, periods):
        """Check an entire consecutive block (used for labs)."""
        for p in periods:
            if self.is_break(p):
                return False
            if not self.is_faculty_free(faculty_id, day, p):
                return False
            if not self.is_class_free(class_id, day, p):
                return False
            if not self.is_room_free(room_id, day, p):
                return False
        return True

    # ---- assign / undo (the "assign" and "backtrack/remove" steps) --

    def assign(self, class_id, subject_id, faculty_id, room_id, day, periods):
        for p in periods:
            self.faculty_busy.add((faculty_id, day, p))
            self.class_busy.add((class_id, day, p))
            self.room_busy.add((room_id, day, p))

        self.faculty_day_load[(faculty_id, day)] = self.faculty_day_load.get((faculty_id, day), 0) + len(periods)
        self.subject_day_count[(class_id, subject_id, day)] = self.subject_day_count.get((class_id, subject_id, day), 0) + 1

        record = {
            "class_id": class_id,
            "subject_id": subject_id,
            "faculty_id": faculty_id,
            "room_id": room_id,
            "day": day,
            "periods": list(periods),
        }
        self.assignments.append(record)
        return record

    def undo(self, record):
        """Backtrack step: remove an assignment completely."""
        for p in record["periods"]:
            self.faculty_busy.discard((record["faculty_id"], record["day"], p))
            self.class_busy.discard((record["class_id"], record["day"], p))
            self.room_busy.discard((record["room_id"], record["day"], p))

        key = (record["faculty_id"], record["day"])
        self.faculty_day_load[key] = max(0, self.faculty_day_load.get(key, 0) - len(record["periods"]))

        skey = (record["class_id"], record["subject_id"], record["day"])
        self.subject_day_count[skey] = max(0, self.subject_day_count.get(skey, 0) - 1)

        self.assignments.remove(record)


def faculty_marked_available(faculty_availability_map, faculty_id, day, period):
    """
    faculty_availability_map: dict[(faculty_id, day, period)] -> bool
    Faculty are assumed AVAILABLE unless explicitly marked unavailable
    on the Faculty Availability grid.
    """
    return faculty_availability_map.get((faculty_id, day, period), True)


def find_consecutive_windows(teaching_periods, block_size):
    """
    Given the ordered list of non-break teaching periods, return every
    window of `block_size` periods that are physically consecutive
    (no break period in between, no gap in period numbering).

    e.g. teaching_periods = [1,2,3,5,6,7], block_size = 2
         -> windows: [1,2], [2,3], [5,6], [6,7]
    """
    windows = []
    for i in range(len(teaching_periods) - block_size + 1):
        window = teaching_periods[i:i + block_size]
        # must be numerically consecutive (period 3 -> 4 -> 5, not 3 -> 5)
        if all(window[j + 1] - window[j] == 1 for j in range(len(window) - 1)):
            windows.append(window)
    return windows
