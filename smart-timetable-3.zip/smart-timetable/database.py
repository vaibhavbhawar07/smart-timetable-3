"""
database.py
------------
Handles SQLite connection and schema creation for the
Smart Time Table Scheduling System.

DATA STRUCTURE NOTE (for viva):
Every table below maps directly onto a Python dictionary/list
once loaded into the scheduler, so the relational schema here
is really just a persistent form of the in-memory hash maps
the backtracking algorithm works with.
"""

import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "database.db")


def get_connection():
    """Return a SQLite connection with foreign keys enabled and
    rows accessible like dictionaries (row['column'])."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


SCHEMA = """
CREATE TABLE IF NOT EXISTS classes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    class_name TEXT NOT NULL,
    division TEXT NOT NULL,
    academic_year TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS faculty (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    faculty_name TEXT NOT NULL,
    email TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS subjects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    subject_name TEXT NOT NULL,
    faculty_id INTEGER NOT NULL,
    class_id INTEGER NOT NULL,
    lectures_per_week INTEGER NOT NULL,
    subject_type TEXT NOT NULL DEFAULT 'Theory',   -- 'Theory' or 'Lab'
    requires_consecutive_periods INTEGER NOT NULL DEFAULT 0,  -- 0/1
    block_size INTEGER NOT NULL DEFAULT 1,          -- periods per lab session
    FOREIGN KEY (faculty_id) REFERENCES faculty(id) ON DELETE CASCADE,
    FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS faculty_availability (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    faculty_id INTEGER NOT NULL,
    day TEXT NOT NULL,
    time_slot INTEGER NOT NULL,      -- references time_slots.period_index
    available INTEGER NOT NULL DEFAULT 1,  -- 0/1
    FOREIGN KEY (faculty_id) REFERENCES faculty(id) ON DELETE CASCADE,
    UNIQUE(faculty_id, day, time_slot)
);

CREATE TABLE IF NOT EXISTS rooms (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    room_name TEXT NOT NULL,
    room_type TEXT NOT NULL DEFAULT 'Classroom',  -- 'Classroom' or 'Lab'
    capacity INTEGER NOT NULL DEFAULT 60
);

CREATE TABLE IF NOT EXISTS time_slots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    period_index INTEGER NOT NULL UNIQUE,
    start_time TEXT NOT NULL,
    end_time TEXT NOT NULL,
    is_break INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
);

CREATE TABLE IF NOT EXISTS timetable (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    class_id INTEGER NOT NULL,
    subject_id INTEGER NOT NULL,
    faculty_id INTEGER NOT NULL,
    room_id INTEGER NOT NULL,
    day TEXT NOT NULL,
    time_slot INTEGER NOT NULL,
    FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
    FOREIGN KEY (faculty_id) REFERENCES faculty(id) ON DELETE CASCADE,
    FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS conflict_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    message TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
"""

DEFAULT_WORKING_DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri"]


def init_db(reset=False):
    """Create tables if they do not exist. If reset=True, drop and
    recreate everything (used by the 'Reset Demo Data' action)."""
    conn = get_connection()
    cur = conn.cursor()

    if reset:
        cur.executescript("""
            DROP TABLE IF EXISTS timetable;
            DROP TABLE IF EXISTS conflict_log;
            DROP TABLE IF EXISTS faculty_availability;
            DROP TABLE IF EXISTS subjects;
            DROP TABLE IF EXISTS rooms;
            DROP TABLE IF EXISTS time_slots;
            DROP TABLE IF EXISTS settings;
            DROP TABLE IF EXISTS classes;
            DROP TABLE IF EXISTS faculty;
        """)

    cur.executescript(SCHEMA)

    # Default settings (working days + break period) if not present
    cur.execute("SELECT COUNT(*) AS c FROM settings")
    if cur.fetchone()["c"] == 0:
        cur.execute("INSERT INTO settings (key, value) VALUES (?, ?)",
                    ("working_days", ",".join(DEFAULT_WORKING_DAYS)))

    # Default time slots (9am - 4pm, 1 hour periods, break after period 4)
    cur.execute("SELECT COUNT(*) AS c FROM time_slots")
    if cur.fetchone()["c"] == 0:
        default_slots = [
            (1, "09:00", "10:00", 0),
            (2, "10:00", "11:00", 0),
            (3, "11:00", "12:00", 0),
            (4, "12:00", "13:00", 1),   # lunch break
            (5, "13:00", "14:00", 0),
            (6, "14:00", "15:00", 0),
            (7, "15:00", "16:00", 0),
        ]
        cur.executemany(
            "INSERT INTO time_slots (period_index, start_time, end_time, is_break) VALUES (?,?,?,?)",
            default_slots
        )

    conn.commit()
    conn.close()


def seed_demo_data():
    """Insert sample classes/faculty/subjects/rooms so the app is
    demonstrable immediately after first install."""
    conn = get_connection()
    cur = conn.cursor()

    cur.execute("SELECT COUNT(*) AS c FROM classes")
    if cur.fetchone()["c"] > 0:
        conn.close()
        return  # already seeded

    # Faculty
    faculty = ["Prof. Sharma", "Prof. Verma", "Prof. Iyer", "Prof. Khan", "Prof. Das"]
    faculty_ids = []
    for name in faculty:
        cur.execute("INSERT INTO faculty (faculty_name, email) VALUES (?, ?)",
                    (name, name.lower().replace(" ", "").replace(".", "") + "@college.edu"))
        faculty_ids.append(cur.lastrowid)

    # Classes
    cur.execute("INSERT INTO classes (class_name, division, academic_year) VALUES (?,?,?)",
                ("SE Computer", "A", "2025-26"))
    class_id = cur.lastrowid

    # Rooms
    cur.execute("INSERT INTO rooms (room_name, room_type, capacity) VALUES (?,?,?)",
                ("Room 201", "Classroom", 70))
    cur.execute("INSERT INTO rooms (room_name, room_type, capacity) VALUES (?,?,?)",
                ("Room 202", "Classroom", 70))
    cur.execute("INSERT INTO rooms (room_name, room_type, capacity) VALUES (?,?,?)",
                ("Computer Lab 1", "Lab", 35))
    cur.execute("INSERT INTO rooms (room_name, room_type, capacity) VALUES (?,?,?)",
                ("Electronics Lab", "Lab", 30))

    # Subjects: (name, faculty_index, lectures/week, type, consecutive, block_size)
    subjects = [
        ("Data Structures & Algorithms", 0, 4, "Theory", 0, 1),
        ("Database Management Systems", 1, 4, "Theory", 0, 1),
        ("Computer Networks", 2, 3, "Theory", 0, 1),
        ("Operating Systems", 3, 3, "Theory", 0, 1),
        ("Discrete Mathematics", 4, 2, "Theory", 0, 1),
        ("DSA Lab", 0, 2, "Lab", 1, 2),
        ("DBMS Lab", 1, 2, "Lab", 1, 2),
    ]
    for name, f_idx, lpw, s_type, consec, block in subjects:
        cur.execute("""
            INSERT INTO subjects
            (subject_name, faculty_id, class_id, lectures_per_week, subject_type,
             requires_consecutive_periods, block_size)
            VALUES (?,?,?,?,?,?,?)
        """, (name, faculty_ids[f_idx], class_id, lpw, s_type, consec, block))

    conn.commit()
    conn.close()


if __name__ == "__main__":
    init_db()
    seed_demo_data()
    print("Database initialized at", DB_PATH)
