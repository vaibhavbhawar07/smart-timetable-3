// Smart Time Table Scheduling System — client-side behaviour
// Kept deliberately small: the real work happens server-side in Flask.

document.addEventListener("DOMContentLoaded", function () {

  // ---- Faculty availability grid: click a cell to toggle it ----
  document.querySelectorAll(".avail-cell").forEach(function (cell) {
    cell.addEventListener("click", function () {
      var facultyId = cell.dataset.faculty;
      var day = cell.dataset.day;
      var period = cell.dataset.period;

      fetch("/availability/toggle", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "faculty_id=" + encodeURIComponent(facultyId) +
              "&day=" + encodeURIComponent(day) +
              "&period=" + encodeURIComponent(period)
      })
        .then(function (res) { return res.json(); })
        .then(function (data) {
          if (data.available) {
            cell.classList.remove("no");
            cell.classList.add("yes");
            cell.textContent = "✓";
          } else {
            cell.classList.remove("yes");
            cell.classList.add("no");
            cell.textContent = "✕";
          }
        })
        .catch(function () {
          alert("Could not update availability. Please try again.");
        });
    });
  });

  // ---- Generate Timetable: show a running/loading banner ----
  var generateForm = document.getElementById("generate-form");
  if (generateForm) {
    generateForm.addEventListener("submit", function () {
      var banner = document.getElementById("loading-banner");
      var button = document.getElementById("generate-btn");
      if (banner) banner.style.display = "flex";
      if (button) {
        button.disabled = true;
        button.textContent = "Running scheduling algorithm...";
      }
    });
  }

  // ---- Print button ----
  document.querySelectorAll(".js-print").forEach(function (btn) {
    btn.addEventListener("click", function () { window.print(); });
  });

  // ---- Lab consecutive-periods toggle shows/hides block size field ----
  var consecCheckbox = document.getElementById("requires_consecutive_periods");
  var blockField = document.getElementById("block-size-field");
  if (consecCheckbox && blockField) {
    var sync = function () { blockField.style.display = consecCheckbox.checked ? "block" : "none"; };
    consecCheckbox.addEventListener("change", sync);
    sync();
  }
});
