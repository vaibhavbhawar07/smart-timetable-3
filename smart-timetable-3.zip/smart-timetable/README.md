# Smart Time Table Scheduling System

A 2nd-year Engineering DSA mini-project: a real, working Flask web application
that generates a conflict-free weekly college timetable using **Constraint
Satisfaction + Greedy prioritization + recursive Backtracking** — not random
placement, not a static demo.

---

## 1. Tech Stack

| Layer      | Technology                          |
|------------|--------------------------------------|
| Frontend   | HTML5, CSS3, vanilla JavaScript (responsive) |
| Backend    | Python 3 + Flask                     |
| Database   | SQLite                               |
| Algorithm  | Greedy ordering + recursive Backtracking CSP solver |

---

## 2. Project Structure

```
smart-timetable/
│
├── app.py                    # Flask routes (HTTP layer only)
├── database.py                # SQLite schema + demo data seeding
├── requirements.txt
│
├── scheduler/                 # ALL of the DSA logic lives here
│   ├── __init__.py
│   ├── constraints.py         # ScheduleState + hard-constraint checks (CSP rules)
│   ├── greedy.py               # priority ordering + session expansion
│   ├── backtracking.py        # the recursive backtracking search
│   └── optimizer.py           # soft-constraint quality scoring
│
├── templates/                 # Jinja2 HTML pages (11 pages, see below)
├── static/
│   ├── css/style.css
│   └── js/script.js
│
└── README.md
```

---

## 3. Installation

**Requirements:** Python 3.9+

```bash
cd smart-timetable
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## 4. Running the Project

```bash
python3 app.py
```

Flask will start on **http://127.0.0.1:5000**. The database (`database.db`)
and demo data (1 class, 5 faculty, 7 subjects, 4 rooms) are created
automatically the first time you run it.

To wipe everything and reload the demo dataset at any time, click
**"Reset demo data"** at the bottom of the sidebar in the running app.

## 5. Adding Your Own Data

Use the sidebar, top to bottom:

1. **Classes** — add each class/division (e.g. "SE Computer", division "A").
2. **Subjects** — add subjects, pick the class + faculty, set lectures/week,
   mark Theory or Lab, and tick "Requires consecutive periods" for labs.
3. **Faculty** — add teaching staff.
4. **Availability** — pick a faculty member and click cells on the grid to
   mark them unavailable (green = free, red = blocked). Everything is
   available by default.
5. **Rooms & Labs** — add classrooms and labs (room *type* matters — labs
   are only assigned to Lab-type rooms).
6. **Time Slots** — set working days, start time, number of periods, period
   length, and where the lunch/break period goes.
7. **Generate Timetable** — click **GENERATE SMART TIMETABLE**.

## 6. How Timetable Generation Works

1. **Validation** — before running anything, the app checks subjects, rooms,
   faculty and time slots all exist, and that no subject asks for more
   lectures than there are periods in the week. If validation fails, you get
   a clear message and nothing is generated.
2. **Greedy ordering** (`scheduler/greedy.py`) — subjects are sorted
   hardest-first: Labs → subjects whose faculty has the least free time →
   subjects needing consecutive periods → subjects with the most weekly
   lectures → ordinary theory subjects. Each subject is then expanded into
   individual "sessions" (a 4-lecture theory subject becomes 4 sessions of
   size 1; a 2-session lab with 2-period blocks stays as 2 sessions of size 2).
3. **Backtracking search** (`scheduler/backtracking.py`) — a recursive
   function tries to place session 0, then session 1, and so on. For each
   session it builds every legal (day, period-window, room) candidate,
   sorted by a soft-constraint score, and tries them in order:
   - If a candidate satisfies every hard constraint, it's assigned and the
     function recurses to the next session.
   - If that recursive call eventually fails, the assignment is **undone**
     (backtracked) and the next candidate is tried.
   - If no candidate works, the function reports failure back up one level,
     which triggers *that* level to backtrack too.
4. **Scoring** (`scheduler/optimizer.py`) — once a full (or partial)
   timetable exists, a 0–100 quality score is computed from constraint
   satisfaction, subject distribution across the week, faculty workload
   balance, and how many same-subject lectures ended up back-to-back.
5. **Result** — a complete timetable is shown on the Timetable page with the
   score, or, if some sessions genuinely couldn't be placed, the exact
   reason appears on the Conflict Report page. **The app never silently
   displays an invalid or partial timetable as if it were complete.**

## 7. Where the DSA Algorithm Lives

All of it is in the `scheduler/` package, deliberately kept separate from
Flask/HTTP code:

- `scheduler/constraints.py` — the `ScheduleState` class (hash sets for
  O(1) faculty/class/room conflict checks) and the hard-constraint rules.
- `scheduler/greedy.py` — the priority heuristic and session expansion.
- `scheduler/backtracking.py` — the actual recursive `schedule()`-style
  search (function `_backtrack`), matching the pseudocode in the brief.
- `scheduler/optimizer.py` — soft-constraint scoring.

## 8. Demonstrating It to a Professor

A good 5-minute walkthrough:

1. Show the pre-loaded demo data (Classes → Subjects → Faculty → Rooms).
2. Open **Availability**, mark a faculty member unavailable for a slot, and
   explain that the algorithm will now respect that automatically.
3. Click **Generate Timetable** and show the loading state, then the result
   grid + score.
4. Delete a room (e.g. remove the only Lab) and regenerate to show the
   **Conflict Report** clearly explaining what's missing — this proves the
   constraint checking is real, not cosmetic.
5. Open **About Project** and walk through the pseudocode / complexity
   section using the viva Q&A at the bottom.

## 9. Modifying the Project Later

- **Add a new hard constraint:** add a method to `ScheduleState` in
  `constraints.py` and call it inside `block_is_free()`.
- **Change the priority order:** edit `priority_key()` in `greedy.py`.
- **Change the scoring weights:** edit the four `_..._score()` functions in
  `optimizer.py` (they currently sum to 100).
- **Add a new page:** add a Flask route in `app.py`, a template in
  `templates/`, and a sidebar link in `templates/base.html`.

---

## 10. DSA Documentation

### Problem Statement
Given classes, subjects (with a faculty and a weekly lecture count), faculty
availability, rooms/labs, and a weekly period structure, produce a complete
weekly timetable satisfying every hard constraint, or prove that none exists.

### Why This Is a Constraint Satisfaction Problem
A CSP consists of **variables** (things to decide), a **domain** of possible
values for each, and **constraints** restricting valid combinations. Here:
- Variables = every lecture *session* that needs a slot.
- Domain = every (day, starting period, room) triple.
- Constraints = the 10 hard rules (no double-booking of faculty/class/room,
  full weekly lecture counts, respecting faculty unavailability and break
  periods, consecutive lab periods, etc.)

This is a textbook CSP, and in general (like graph colouring, to which it is
closely related) it is **NP-hard** — which is exactly why the project uses
Greedy ordering + Backtracking rather than a naive brute-force scan.

### Data Structures Used
| Structure | Where | Why |
|---|---|---|
| Lists | ordered session queue, time slot list | Order matters for greedy priority |
| Dictionaries / hash maps | faculty availability, day-load counters | O(1) average lookup |
| Sets | `faculty_busy`, `class_busy`, `room_busy` | O(1) conflict detection |
| Recursion / call stack | the backtracking search | Each frame = one session placement decision |
| Conflict graph (conceptual) | nodes = class/faculty/room, edges = "cannot share a slot" | The `*_busy` sets are an efficient encoding of this graph without storing edges explicitly |

### Greedy Algorithm
Implemented in `scheduler/greedy.py::order_subjects()` / `priority_key()`.
Subjects are sorted by a tuple `(is_lab, availability_count, needs_consecutive,
-lectures_per_week, name)` — Python sorts tuples lexicographically, so this
single `sorted()` call reproduces the exact 5-level priority order requested
in the brief.

### Backtracking Algorithm
```
function schedule(index):
    if index == total_sessions:
        return success

    session = sessions[index]
    for (day, room, periods) in candidates(session):   # best-first, soft-scored
        if constraints_satisfied(day, room, periods):   # hard constraints
            assign(session, day, room, periods)
            if schedule(index + 1):
                return success
            undo(session)                                # BACKTRACK
    return failure
```
Implemented as `_backtrack()` in `scheduler/backtracking.py`. Correctness
argument: the function only returns success once every session has a
constraint-satisfying assignment, and it exhaustively tries every ordering
before declaring failure for a session — so if *any* valid full assignment
exists in the search space, this function will find it.

### Constraint Checking
Every hard constraint from the brief maps directly onto a check in
`scheduler/constraints.py`:

| # | Constraint | Enforced by |
|---|---|---|
| 1 | Faculty can't teach two classes at once | `faculty_busy` set |
| 2 | Class can't have two subjects at once | `class_busy` set |
| 3 | Room can't be double-booked | `room_busy` set |
| 4 | Every subject gets required lectures/week | session expansion + `sessions_scheduled` check |
| 5 | Faculty unavailable periods unused | `faculty_marked_available()` filter |
| 6 | Break periods stay empty | `find_consecutive_windows()` only returns teaching periods |
| 7 | Labs use consecutive periods | block-sized session + consecutive-window generator |
| 8 | Room must be free before assignment | `is_room_free()` |
| 9 | All required subjects scheduled | success only when every session placed |
| 10 | No duplicate assignment | assigning always checks `*_busy` sets first |

### Time Complexity
Worst case: **O((days × periods × rooms)<sup>n</sup>)** where *n* is the
number of sessions — the search tree branches at every session. In practice,
the Greedy ordering places the most constrained sessions first (so bad
branches are pruned within one or two recursion levels), and typical college
timetables solve in well under a second (see the "Backtracking steps taken"
counter on the Conflict Report / generation result).

### Space Complexity
**O(n)** for the recursion stack (n = sessions) plus **O(days × periods)**
for each of the three busy-sets — small and roughly constant for a given
school's schedule size.

### Advantages
- Never produces an invalid timetable — hard constraints are guaranteed.
- Greedy ordering keeps real-world performance fast despite exponential
  worst-case complexity.
- Hard vs. soft constraints are cleanly separated and independently scored.

### Limitations
- Worst-case exponential runtime on badly over-constrained inputs (capped
  with a backtracking step limit so the app never hangs).
- Soft-constraint ordering is a heuristic, not a provably optimal solution.
- Assumes an identical period structure on every working day.

### Future Scope
- Constraint propagation (forward checking / arc consistency) for earlier pruning.
- Local search / simulated annealing hybrid for very large colleges.
- Shared elective subjects across multiple classes; room-capacity-aware assignment.
- Multi-department logins.

---

## 11. Likely Viva Questions & Answers

**Q: Why did you use Backtracking?**
A: Timetabling has hard constraints that must never be violated. Backtracking
explores the search space while checking constraints at every step and undoes
any choice that leads to a dead end, guaranteeing a valid result if one exists.

**Q: What is a constraint?**
A: A rule restricting which values a variable may take — here, which
(day, period, room) a lecture session may legally occupy.

**Q: Why is timetable scheduling a CSP?**
A: It has variables (sessions), domains (day/period/room options), and
constraints (no double-booking, availability, consecutive periods, etc.) —
exactly the definition of a Constraint Satisfaction Problem.

**Q: What is the time complexity?**
A: Exponential in the worst case, O((days×periods×rooms)^sessions), but
Greedy ordering and constraint pruning make it fast in practice.

**Q: What happens when no valid timetable exists?**
A: The search exhausts every candidate and returns failure; the app reports
exactly which sessions couldn't be placed and why on the Conflict Report —
it never silently shows an invalid timetable.

**Q: Why is Greedy used?**
A: To decide the order sessions are attempted in — scheduling the
hardest-to-place sessions first means bad branches fail fast instead of
wasting search time on easy subjects.

**Q: What data structures are used?**
A: Hash sets for O(1) conflict lookup, dictionaries for availability/workload,
lists for ordered sessions, and the recursion call stack for the search.

**Q: How are faculty conflicts detected?**
A: A `(faculty_id, day, period)` tuple is added to a `faculty_busy` set on
assignment; before assigning, membership is checked in O(1).

**Q: How are lab periods handled?**
A: Labs are expanded into "block" sessions of N consecutive periods, and the
candidate generator only offers numerically consecutive, non-break windows.

**Q: How can the project be optimized in future?**
A: Add constraint propagation to prune the search tree earlier, or switch to
a metaheuristic (simulated annealing / genetic algorithm) for very large
timetables where pure backtracking becomes slow.

---

## 12. Application Pages

1. Home / Dashboard
2. Class Management
3. Subject Management
4. Faculty Management
5. Faculty Availability
6. Room / Lab Management
7. Time Slot Management
8. Generate Timetable
9. Generated Timetable (with score + export)
10. Conflict Report
11. About Project (this documentation, inside the app)

## 13. Export Options

- **Print** — opens the browser print dialog with a print-friendly stylesheet.
- **Download PDF** — uses the same browser print dialog; choose "Save as PDF"
  as the destination (kept dependency-free rather than requiring a system
  PDF renderer like wkhtmltopdf).
- **Export CSV** — downloads the full timetable as a `.csv` file.
