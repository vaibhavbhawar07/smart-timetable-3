"""
app.py
-------
Flask application for the Smart Time Table Scheduling System.

This file only handles HTTP routing, form parsing and talking to
SQLite. All of the actual DSA (Greedy ordering + Backtracking CSP
solving + scoring) lives in the `scheduler/` package -- see
scheduler/backtracking.py for the recursive algorithm.
"""

import csv
import io
import json

from flask import Flask, render_template, request, redirect, url_for, flash, Response

from database import init_db, seed_demo_data, get_connection
from scheduler.backtracking import generate_timetable
from scheduler.optimizer import calculate_score

app = Flask(__name__)
app.secret_key = "smart-timetable-dsa-project-secret-key"  # fine for a local student project


# ----------------------------------------------------------------------
# Small data-access helpers (kept together so routes stay readable)
# ----------------------------------------------------------------------

def get_working_days():
    conn = get_connection()
    row = conn.execute("SELECT value FROM settings WHERE key='working_days'").fetchone()
    conn.close()
    return row["value"].split(",") if row else ["Mon", "Tue", "Wed", "Thu", "Fri"]


def set_working_days(days):
    conn = get_connection()
    conn.execute("UPDATE settings SET value=? WHERE key='working_days'", (",".join(days),))
    conn.commit()
    conn.close()


def get_time_slots():
    conn = get_connection()
    rows = conn.execute("SELECT * FROM time_slots ORDER BY period_index").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_classes():
    conn = get_connection()
    rows = conn.execute("SELECT * FROM classes ORDER BY id").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_faculty():
    conn = get_connection()
    rows = conn.execute("SELECT * FROM faculty ORDER BY id").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_rooms():
    conn = get_connection()
    rows = conn.execute("SELECT * FROM rooms ORDER BY id").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_subjects():
    conn = get_connection()
    rows = conn.execute("""
        SELECT subjects.*, faculty.faculty_name, classes.class_name, classes.division
        FROM subjects
        JOIN faculty ON subjects.faculty_id = faculty.id
        JOIN classes ON subjects.class_id = classes.id
        ORDER BY subjects.id
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_faculty_availability_map():
    """dict[(faculty_id, day, period)] -> bool(available)"""
    conn = get_connection()
    rows = conn.execute("SELECT * FROM faculty_availability").fetchall()
    conn.close()
    return {(r["faculty_id"], r["day"], r["time_slot"]): bool(r["available"]) for r in rows}


def counts_summary():
    conn = get_connection()
    c = {
        "classes": conn.execute("SELECT COUNT(*) c FROM classes").fetchone()["c"],
        "subjects": conn.execute("SELECT COUNT(*) c FROM subjects").fetchone()["c"],
        "faculty": conn.execute("SELECT COUNT(*) c FROM faculty").fetchone()["c"],
        "rooms": conn.execute("SELECT COUNT(*) c FROM rooms").fetchone()["c"],
        "timetable_entries": conn.execute("SELECT COUNT(*) c FROM timetable").fetchone()["c"],
    }
    conn.close()
    return c


# ----------------------------------------------------------------------
# Home
# ----------------------------------------------------------------------

@app.route("/")
def home():
    return render_template("index.html", counts=counts_summary())


# ----------------------------------------------------------------------
# Class Management
# ----------------------------------------------------------------------

@app.route("/classes", methods=["GET", "POST"])
def classes():
    if request.method == "POST":
        name = request.form.get("class_name", "").strip()
        division = request.form.get("division", "").strip()
        year = request.form.get("academic_year", "").strip()
        if not name or not division:
            flash("Class name and division are required.", "error")
        else:
            conn = get_connection()
            conn.execute("INSERT INTO classes (class_name, division, academic_year) VALUES (?,?,?)",
                         (name, division, year))
            conn.commit()
            conn.close()
            flash(f"Class '{name} {division}' added.", "success")
        return redirect(url_for("classes"))

    return render_template("classes.html", classes=get_classes())


@app.route("/classes/delete/<int:class_id>", methods=["POST"])
def delete_class(class_id):
    conn = get_connection()
    conn.execute("DELETE FROM classes WHERE id=?", (class_id,))
    conn.commit()
    conn.close()
    flash("Class deleted.", "success")
    return redirect(url_for("classes"))


# ----------------------------------------------------------------------
# Faculty Management
# ----------------------------------------------------------------------

@app.route("/faculty", methods=["GET", "POST"])
def faculty():
    if request.method == "POST":
        name = request.form.get("faculty_name", "").strip()
        email = request.form.get("email", "").strip()
        if not name:
            flash("Faculty name is required.", "error")
        else:
            conn = get_connection()
            conn.execute("INSERT INTO faculty (faculty_name, email) VALUES (?,?)", (name, email))
            conn.commit()
            conn.close()
            flash(f"Faculty '{name}' added.", "success")
        return redirect(url_for("faculty"))

    return render_template("faculty.html", faculty=get_faculty())


@app.route("/faculty/edit/<int:faculty_id>", methods=["POST"])
def edit_faculty(faculty_id):
    name = request.form.get("faculty_name", "").strip()
    email = request.form.get("email", "").strip()
    conn = get_connection()
    conn.execute("UPDATE faculty SET faculty_name=?, email=? WHERE id=?", (name, email, faculty_id))
    conn.commit()
    conn.close()
    flash("Faculty updated.", "success")
    return redirect(url_for("faculty"))


@app.route("/faculty/delete/<int:faculty_id>", methods=["POST"])
def delete_faculty(faculty_id):
    conn = get_connection()
    conn.execute("DELETE FROM faculty WHERE id=?", (faculty_id,))
    conn.commit()
    conn.close()
    flash("Faculty deleted.", "success")
    return redirect(url_for("faculty"))


# ----------------------------------------------------------------------
# Subject Management
# ----------------------------------------------------------------------

@app.route("/subjects", methods=["GET", "POST"])
def subjects():
    if request.method == "POST":
        name = request.form.get("subject_name", "").strip()
        faculty_id = request.form.get("faculty_id")
        class_id = request.form.get("class_id")
        lectures = request.form.get("lectures_per_week", "0")
        subject_type = request.form.get("subject_type", "Theory")
        consecutive = 1 if request.form.get("requires_consecutive_periods") == "on" else 0
        block_size = request.form.get("block_size", "2") if consecutive else 1

        if not name or not faculty_id or not class_id:
            flash("Subject name, faculty and class are required.", "error")
        else:
            conn = get_connection()
            conn.execute("""
                INSERT INTO subjects
                (subject_name, faculty_id, class_id, lectures_per_week, subject_type,
                 requires_consecutive_periods, block_size)
                VALUES (?,?,?,?,?,?,?)
            """, (name, faculty_id, class_id, int(lectures), subject_type, consecutive, int(block_size)))
            conn.commit()
            conn.close()
            flash(f"Subject '{name}' added.", "success")
        return redirect(url_for("subjects"))

    return render_template("subjects.html", subjects=get_subjects(),
                            faculty=get_faculty(), classes=get_classes())


@app.route("/subjects/delete/<int:subject_id>", methods=["POST"])
def delete_subject(subject_id):
    conn = get_connection()
    conn.execute("DELETE FROM subjects WHERE id=?", (subject_id,))
    conn.commit()
    conn.close()
    flash("Subject deleted.", "success")
    return redirect(url_for("subjects"))


# ----------------------------------------------------------------------
# Faculty Availability
# ----------------------------------------------------------------------

@app.route("/availability", methods=["GET"])
def availability():
    fac_list = get_faculty()
    days = get_working_days()
    slots = [s for s in get_time_slots() if not s["is_break"]]
    selected_id = request.args.get("faculty_id", type=int)
    if not selected_id and fac_list:
        selected_id = fac_list[0]["id"]

    avail_map = get_faculty_availability_map()
    grid = {}
    for slot in slots:
        for day in days:
            grid[(slot["period_index"], day)] = avail_map.get((selected_id, day, slot["period_index"]), True)

    return render_template("availability.html", faculty=fac_list, days=days, slots=slots,
                            selected_id=selected_id, grid=grid)


@app.route("/availability/toggle", methods=["POST"])
def toggle_availability():
    faculty_id = request.form.get("faculty_id", type=int)
    day = request.form.get("day")
    period = request.form.get("period", type=int)

    conn = get_connection()
    existing = conn.execute(
        "SELECT * FROM faculty_availability WHERE faculty_id=? AND day=? AND time_slot=?",
        (faculty_id, day, period)
    ).fetchone()

    if existing:
        new_val = 0 if existing["available"] else 1
        conn.execute("UPDATE faculty_availability SET available=? WHERE id=?", (new_val, existing["id"]))
    else:
        # not in table yet -> was implicitly available(1); toggle to unavailable(0)
        new_val = 0
        conn.execute(
            "INSERT INTO faculty_availability (faculty_id, day, time_slot, available) VALUES (?,?,?,?)",
            (faculty_id, day, period, new_val)
        )
    conn.commit()
    conn.close()
    return {"available": bool(new_val)}


# ----------------------------------------------------------------------
# Room / Lab Management
# ----------------------------------------------------------------------

@app.route("/rooms", methods=["GET", "POST"])
def rooms():
    if request.method == "POST":
        name = request.form.get("room_name", "").strip()
        room_type = request.form.get("room_type", "Classroom")
        capacity = request.form.get("capacity", "60")
        if not name:
            flash("Room name is required.", "error")
        else:
            conn = get_connection()
            conn.execute("INSERT INTO rooms (room_name, room_type, capacity) VALUES (?,?,?)",
                         (name, room_type, int(capacity)))
            conn.commit()
            conn.close()
            flash(f"Room '{name}' added.", "success")
        return redirect(url_for("rooms"))

    return render_template("rooms.html", rooms=get_rooms())


@app.route("/rooms/delete/<int:room_id>", methods=["POST"])
def delete_room(room_id):
    conn = get_connection()
    conn.execute("DELETE FROM rooms WHERE id=?", (room_id,))
    conn.commit()
    conn.close()
    flash("Room deleted.", "success")
    return redirect(url_for("rooms"))


# ----------------------------------------------------------------------
# Time Slot Management
# ----------------------------------------------------------------------

ALL_DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]


@app.route("/slots", methods=["GET", "POST"])
def slots():
    if request.method == "POST":
        selected_days = request.form.getlist("working_days")
        if not selected_days:
            flash("Select at least one working day.", "error")
            return redirect(url_for("slots"))
        set_working_days(selected_days)

        start_time = request.form.get("start_time", "09:00")
        num_periods = int(request.form.get("num_periods", "6"))
        period_length = int(request.form.get("period_length", "60"))
        break_after = int(request.form.get("break_after", "3"))

        # Rebuild the time_slots table from these settings
        from datetime import datetime, timedelta
        conn = get_connection()
        conn.execute("DELETE FROM time_slots")
        cur_time = datetime.strptime(start_time, "%H:%M")
        period_index = 1
        for i in range(num_periods + 1):  # +1 slot reserved for the break
            end_time = cur_time + timedelta(minutes=period_length)
            is_break = 1 if period_index == break_after + 1 else 0
            conn.execute(
                "INSERT INTO time_slots (period_index, start_time, end_time, is_break) VALUES (?,?,?,?)",
                (period_index, cur_time.strftime("%H:%M"), end_time.strftime("%H:%M"), is_break)
            )
            cur_time = end_time
            period_index += 1
        conn.commit()
        conn.close()
        flash("Time slot configuration updated.", "success")
        return redirect(url_for("slots"))

    return render_template("slots.html", time_slots=get_time_slots(),
                            working_days=get_working_days(), all_days=ALL_DAYS)


# ----------------------------------------------------------------------
# Timetable Generation
# ----------------------------------------------------------------------

@app.route("/generate", methods=["GET", "POST"])
def generate():
    validation_errors = []
    subj = get_subjects()
    room_list = get_rooms()
    working_days = get_working_days()
    time_slots_list = get_time_slots()

    if not subj:
        validation_errors.append("No subjects defined. Please add subjects first.")
    if not room_list:
        validation_errors.append("No rooms/labs defined. Please add rooms first.")
    if not get_faculty():
        validation_errors.append("No faculty defined. Please add faculty first.")
    if not any(not t["is_break"] for t in time_slots_list):
        validation_errors.append("No teaching periods configured. Please configure time slots.")

    if request.method == "POST" and not validation_errors:
        avail_map = get_faculty_availability_map()
        result = generate_timetable(subj, room_list, avail_map, working_days, time_slots_list)

        # Persist to DB
        conn = get_connection()
        conn.execute("DELETE FROM timetable")
        conn.execute("DELETE FROM conflict_log")
        for a in result["assignments"]:
            for p in a["periods"]:
                conn.execute("""
                    INSERT INTO timetable (class_id, subject_id, faculty_id, room_id, day, time_slot)
                    VALUES (?,?,?,?,?,?)
                """, (a["class_id"], a["subject_id"], a["faculty_id"], a["room_id"], a["day"], p))
        for msg in result["conflicts"]:
            conn.execute("INSERT INTO conflict_log (message) VALUES (?)", (msg,))

        score, breakdown = calculate_score(result)
        conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('last_score', ?)", (str(score),))
        conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('last_score_breakdown', ?)",
                     (json.dumps(breakdown),))
        conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('last_success', ?)",
                     ("1" if result["success"] else "0",))
        conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('last_steps', ?)",
                     (str(result["steps"]),))
        conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('sessions_total', ?)",
                     (str(result["sessions_total"]),))
        conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('sessions_scheduled', ?)",
                     (str(result["sessions_scheduled"]),))
        conn.commit()
        conn.close()

        if result["success"]:
            flash("Timetable generated successfully!", "success")
            return redirect(url_for("timetable_view"))
        else:
            flash("Timetable could not be fully generated. See the Conflict Report.", "error")
            return redirect(url_for("conflicts_view"))

    return render_template("generate.html", errors=validation_errors,
                            subjects_count=len(subj), rooms_count=len(room_list),
                            working_days=working_days)


@app.route("/timetable")
def timetable_view():
    conn = get_connection()
    rows = conn.execute("""
        SELECT timetable.*, subjects.subject_name, subjects.subject_type,
               faculty.faculty_name, rooms.room_name, classes.class_name, classes.division
        FROM timetable
        JOIN subjects ON timetable.subject_id = subjects.id
        JOIN faculty ON timetable.faculty_id = faculty.id
        JOIN rooms ON timetable.room_id = rooms.id
        JOIN classes ON timetable.class_id = classes.id
    """).fetchall()

    settings_rows = {r["key"]: r["value"] for r in conn.execute("SELECT * FROM settings").fetchall()}
    conn.close()

    working_days = get_working_days()
    time_slots_list = get_time_slots()

    grid = {}
    for r in rows:
        grid[(r["time_slot"], r["day"])] = dict(r)

    score = settings_rows.get("last_score", "--")
    breakdown = json.loads(settings_rows.get("last_score_breakdown", "{}")) if settings_rows.get("last_score_breakdown") else {}

    summary = {
        "total": settings_rows.get("sessions_total", "0"),
        "scheduled_periods": len(rows),
        "success": settings_rows.get("last_success") == "1",
    }

    return render_template("timetable.html", grid=grid, working_days=working_days,
                            time_slots=time_slots_list, score=score, breakdown=breakdown,
                            summary=summary, has_data=len(rows) > 0)


@app.route("/conflicts")
def conflicts_view():
    conn = get_connection()
    rows = conn.execute("SELECT * FROM conflict_log ORDER BY id").fetchall()
    settings_rows = {r["key"]: r["value"] for r in conn.execute("SELECT * FROM settings").fetchall()}
    conn.close()
    return render_template("conflicts.html", conflicts=[dict(r) for r in rows],
                            steps=settings_rows.get("last_steps", "0"),
                            sessions_total=settings_rows.get("sessions_total", "0"),
                            sessions_scheduled=settings_rows.get("sessions_scheduled", "0"))


# ----------------------------------------------------------------------
# Export
# ----------------------------------------------------------------------

@app.route("/export/csv")
def export_csv():
    conn = get_connection()
    rows = conn.execute("""
        SELECT timetable.day, timetable.time_slot, subjects.subject_name,
               faculty.faculty_name, rooms.room_name, classes.class_name, classes.division
        FROM timetable
        JOIN subjects ON timetable.subject_id = subjects.id
        JOIN faculty ON timetable.faculty_id = faculty.id
        JOIN rooms ON timetable.room_id = rooms.id
        JOIN classes ON timetable.class_id = classes.id
        ORDER BY timetable.day, timetable.time_slot
    """).fetchall()
    conn.close()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Day", "Period", "Class", "Subject", "Faculty", "Room"])
    for r in rows:
        writer.writerow([r["day"], r["time_slot"], f"{r['class_name']} {r['division']}",
                          r["subject_name"], r["faculty_name"], r["room_name"]])

    return Response(output.getvalue(), mimetype="text/csv",
                     headers={"Content-Disposition": "attachment;filename=timetable.csv"})


# ----------------------------------------------------------------------
# About
# ----------------------------------------------------------------------

@app.route("/about")
def about():
    return render_template("about.html")


# ----------------------------------------------------------------------
# Reset demo data (handy for viva re-runs)
# ----------------------------------------------------------------------

@app.route("/reset-demo", methods=["POST"])
def reset_demo():
    init_db(reset=True)
    seed_demo_data()
    flash("Database reset to demo data.", "success")
    return redirect(url_for("home"))


if __name__ == "__main__":
    init_db()
    seed_demo_data()
    app.run(debug=True)
